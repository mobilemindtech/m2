package br.com.mobilemind.copyjs.plugin

import org.scalajs.sbtplugin.ScalaJSPlugin
import org.scalajs.sbtplugin.ScalaJSPlugin.autoImport.*
import org.scalajs.linker.interface.Report
import sbt.*
import sbt.Keys.*

import java.io.File
import scala.language.postfixOps


object CopyJSPlugin extends AutoPlugin {
  override def requires = ScalaJSPlugin
  override def trigger = allRequirements

  object autoImport {
    val copyJSToPath = SettingKey[File]("copyJSToPath", "Path to copy")
  }

  import autoImport.*

  private def copyAndRenameTask(linkerTask: TaskKey[Attributed[Report]], dirSetting: SettingKey[File]) = Def.task {
    val report = linkerTask.value
    val src = dirSetting.value
    val dest = copyJSToPath.value
    val fileName = s"${moduleName.value}.js"
    IO.copy(
      Seq(
        (src / "main.js", dest / fileName),
        (src / "main.js.map", dest / s"$fileName.map")
      ),
      CopyOptions(
        overwrite = true,
        preserveLastModified = true,
        preserveExecutable = true
      )
    )

    report
  }

  override lazy val projectSettings: Seq[Setting[?]] = Seq(
    Compile / fastLinkJS := copyAndRenameTask(
      Compile / fastLinkJS,
      Compile / fastLinkJS / scalaJSLinkerOutputDirectory
    ).value,

    Compile / fullLinkJS := copyAndRenameTask(
      Compile / fullLinkJS,
      Compile / fullLinkJS / scalaJSLinkerOutputDirectory
    ).value,
  )
}