package groovyx.net.http;

import java.io.*;

class BufferCopy {

    static ByteArrayOutputStream inputStreamToByteArrayOutputStream(InputStream in) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] bytes = new byte[4096]; // A buffer for reading chunks of data
        int bytesRead;
        while ((bytesRead = in.read(bytes)) != -1) {
            buffer.write(bytes, 0, bytesRead);
        }
        return buffer;
    }

    static StringWriter readerToStringWriter(Reader reader) throws IOException {
        StringWriter buffer = new StringWriter();
        char[] bytes = new char[4096]; // A buffer for reading chunks of data
        int bytesRead;
        while ((bytesRead = reader.read(bytes)) != -1) {
            buffer.write(bytes, 0, bytesRead);
        }
        return buffer;
    }

    static void inputToOutput(InputStream in, OutputStream out) throws IOException {
        byte[] bytes = new byte[4096]; // A buffer for reading chunks of data
        int bytesRead;
        while ((bytesRead = in.read(bytes)) != -1) {
            out.write(bytes, 0, bytesRead);
        }
    }

    static void readerToStringWriter(Reader reader, StringWriter writer) throws IOException {
        char[] bytes = new char[4096]; // A buffer for reading chunks of data
        int bytesRead;
        while ((bytesRead = reader.read(bytes)) != -1) {
            writer.write(bytes, 0, bytesRead);
        }
    }
}
