/*
 * Copyright 2007-2014 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package griffon.test.ast.injection;

import griffon.core.GriffonModelClass;

/**
 * @author Andres Almiray
 * @since 1.5.0
 */
public class GriffonModelTestInjector extends AbstractArtifactTestInjector {
    public String getVariableName() {
        return GriffonModelClass.TYPE;
    }

    public String getArtifactType() {
        return GriffonModelClass.TRAILING;
    }
}