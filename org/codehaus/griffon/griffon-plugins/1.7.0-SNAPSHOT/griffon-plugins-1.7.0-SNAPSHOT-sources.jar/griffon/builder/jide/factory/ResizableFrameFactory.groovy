/*
 * Copyright 2007-2010 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package griffon.builder.jide.factory

import groovy.swing.factory.FrameFactory
import com.jidesoft.swing.ResizableFrame

/**
 * @author Andres Almiray <aalmiray@users.sourceforge.net>
 */
class ResizableFrameFactory extends FrameFactory {
   public Object newInstance(FactoryBuilderSupport builder, Object name, Object value, Map properties) throws InstantiationException, IllegalAccessException {
      if( FactoryBuilderSupport.checkValueIsType(value, name, ResizableFrame) ){
         return value
      }
      ResizableFrame frame = new ResizableFrame()
      handleRootPaneTasks(builder, frame, properties)
      return frame
   }
}