/*
 * Copyright 2009-2014 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.codehaus.griffon.runtime.core;

import griffon.core.GriffonApplication;
import griffon.core.MVCGroup;

import java.util.Map;

/**
 * Default implementation of the {@code MVCGroupConfiguration} interface
 *
 * @author Andres Almiray
 * @since 0.9.3
 */
public class DefaultMVCGroupConfiguration extends AbstractMVCGroupConfiguration {
    public DefaultMVCGroupConfiguration(GriffonApplication app, String mvcType, Map<String, String> members, Map<String, Object> config) {
        super(app, mvcType, members, config);
    }

    protected MVCGroup instantiateMVCGroup(String mvcId, Map<String, Object> args) {
        return app.getMvcGroupManager().buildMVCGroup(getMvcType(), mvcId, args);
    }
}
