/*
 * Copyright 2009-2014 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.codehaus.griffon.runtime.util;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author Andres Almiray
 * @since 1.2.0
 */
public class ExecutorServiceHolder {
    private static final Set<ExecutorService> EXECUTOR_SERVICE_CACHE = new LinkedHashSet<ExecutorService>();

    public static synchronized ExecutorService add(ExecutorService executorService) {
        if (executorService != null) {
            EXECUTOR_SERVICE_CACHE.add(executorService);
        }
        return executorService;
    }

    public static synchronized ExecutorService remove(ExecutorService executorService) {
        EXECUTOR_SERVICE_CACHE.remove(executorService);
        return executorService;
    }

    public static synchronized void shutdownAll() {
        for (Iterator<ExecutorService> it = EXECUTOR_SERVICE_CACHE.iterator(); it.hasNext(); ) {
            ExecutorService executorService = it.next();
            if (!executorService.isShutdown()) {
                executorService.shutdownNow();
            }
            it.remove();
        }
    }

    /**
     * Lazily (re)creates a registered fixed thread pool. Shared pools used to be
     * static finals that stayed dead after {@link #shutdownAll()}, which broke any
     * second application instance in the same JVM (e.g. one per @TestFor test).
     */
    public static final class Lazy {
        private ExecutorService executorService;

        public synchronized ExecutorService get() {
            if (executorService == null || executorService.isShutdown()) {
                executorService = add(Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors()));
            }
            return executorService;
        }
    }
}
