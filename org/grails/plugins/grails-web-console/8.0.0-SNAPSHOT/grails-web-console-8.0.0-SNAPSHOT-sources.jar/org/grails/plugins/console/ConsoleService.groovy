package org.grails.plugins.console

import groovy.util.logging.Slf4j
import org.codehaus.groovy.control.CompilerConfiguration
import org.codehaus.groovy.control.customizers.ImportCustomizer
import grails.core.GrailsApplication
import org.grails.core.artefact.DomainClassArtefactHandler

import java.nio.charset.StandardCharsets

@Slf4j
class ConsoleService {

    GrailsApplication grailsApplication

    /**
     * @param code Groovy code to execute
     * @param autoImportDomains if <code>true</code>, adds imports for each domain class
     * @return an Evaluation
     */
    Evaluation eval(String code, boolean autoImportDomains, request) {
        log.trace "eval() code: $code"

        ByteArrayOutputStream baos = new ByteArrayOutputStream()
        PrintStream out = new PrintStream(baos)

        Evaluation evaluation = new Evaluation()

        Console console = new Console()

        long startTime = System.currentTimeMillis()
        try {
            Binding binding = createBinding(request, out, console)
            CompilerConfiguration configuration = createConfiguration(autoImportDomains)

            GroovyShell groovyShell = new GroovyShell(grailsApplication.classLoader, binding, configuration)
            evaluation.result = groovyShell.evaluate code
        } catch (Throwable t) {
            evaluation.exception = t
        }

        evaluation.totalTime = System.currentTimeMillis() - startTime

        evaluation.console = console
        evaluation.output = baos.toString(StandardCharsets.UTF_8.name())
        evaluation
    }

    private Binding createBinding(request, PrintStream out, Console console) {
        new Binding([
                session          : request.session,
                request          : request,
                ctx              : grailsApplication.mainContext,
                grailsApplication: grailsApplication,
                config           : grailsApplication.config,
                out              : out,
                console          : console
        ])
    }

    private CompilerConfiguration createConfiguration(boolean autoImportDomains) {
        CompilerConfiguration configuration = new CompilerConfiguration()
        if (autoImportDomains) {
            ImportCustomizer importCustomizer = new ImportCustomizer()
            grailsApplication.getArtefacts(DomainClassArtefactHandler.TYPE).each { domainClass ->
                importCustomizer.addImport(domainClass.clazz.simpleName, domainClass.clazz.name)
            }
            configuration.addCompilationCustomizers importCustomizer
        }
        configuration
    }
}
