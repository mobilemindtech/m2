<link rel="stylesheet" media="screen" href="${resource(file: 'console/vendor/bootstrap/css/bootstrap.min.css')}" />
<link rel="stylesheet" media="screen" href="${resource(file: 'console/vendor/font-awesome-4.0.3/css/font-awesome.css')}" />
<link rel="stylesheet" media="screen" href="${resource(file: 'console/vendor/codemirror-5.25.2/lib/codemirror.css')}" />
<link rel="stylesheet" media="screen" href="${resource(file: 'console/vendor/codemirror-5.25.2/theme/lesser-dark.css')}" />
<link rel="stylesheet" media="screen" href="${resource(file: 'console/vendor/jquery-layout/css/jquery.layout.css')}" />
<link rel="stylesheet" media="screen" href="${resource(file: 'console/vendor/jquery-ui-1.10.3/jquery-ui.min.css')}" />
<link rel="stylesheet" media="screen" href="${resource(file: 'console/css/app.1759354167648.css')}" />