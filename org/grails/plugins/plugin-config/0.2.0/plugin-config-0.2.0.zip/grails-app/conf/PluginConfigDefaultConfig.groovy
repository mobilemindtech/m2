grails {
    plugins {
        config {
            autoDefault = true
            sampleValue1 = 1
            sampleValue2 = 'configValue'
        }
    }
}
