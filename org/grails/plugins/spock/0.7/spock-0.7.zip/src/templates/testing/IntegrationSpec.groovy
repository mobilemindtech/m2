@artifact.package@import grails.plugin.spock.IntegrationSpec

class @artifact.name@ extends IntegrationSpec {

	def setup() {
	}

	def cleanup() {
	}

	void "test something"() {
	}
}