eventAssetPrecompileStart = { assetConfig ->
    config.grails.assets.plugin.'console'.excludes = ['**/*']
}