class FamfamfamGrailsPlugin {

	String version = '1.0.1'
	String grailsVersion = '1.0 > *'
	String author = 'Burt Beckwith'
	String authorEmail = 'burt@burtbeckwith.com'
	String title = 'Silk icons from famfamfam.com'
	String description = '1000 free icons from famfamfam.com - see http://www.famfamfam.com/lab/icons/silk/ for details'
	String documentation = 'http://grails.org/plugin/famfamfam'

	List pluginExcludes = ['scripts/_Events.groovy']
}
