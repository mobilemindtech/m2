package grails.plugins.publish;

public interface PluginPublisher {

}
