println '''
*********************************************************
* You've installed the Multi Tenant Single DB plugin.   *
*                                                       *
* The plugin requires some additional steps to enable   *
* multi tenant behavior.                                *
*                                                       *
* Run the "mt-quickstart" script to initialize a simple *
*     tenant, repository and resolver.                  *
* Or, run the "mt-spring-security" script to generate a *
*     tenant, repository and resolver that work with    *
*     the spring-security-core plugin.                  *
*                                                       *
*********************************************************
'''
